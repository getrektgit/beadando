-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Máj 23. 11:32
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `bolt`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `autok`
--

CREATE TABLE `autok` (
  `id` int(11) NOT NULL,
  `márka` varchar(50) NOT NULL,
  `ár` int(11) NOT NULL,
  `végsebesség` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `autok`
--

INSERT INTO `autok` (`id`, `márka`, `ár`, `végsebesség`) VALUES
(1, 'Mercedes', 6500000, 310),
(2, 'BMW', 5800000, 290);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `bicikli`
--

CREATE TABLE `bicikli` (
  `id` int(11) NOT NULL,
  `márka` varchar(50) NOT NULL,
  `ár` int(11) NOT NULL,
  `végsebesség` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `bicikli`
--

INSERT INTO `bicikli` (`id`, `márka`, `ár`, `végsebesség`) VALUES
(1, 'asdwqrefdsg', 23140, 50),
(2, 'gaosndh', 40000, 60);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `roller`
--

CREATE TABLE `roller` (
  `id` int(11) NOT NULL,
  `márka` varchar(50) NOT NULL,
  `ár` int(11) NOT NULL,
  `végsebesség` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `roller`
--

INSERT INTO `roller` (`id`, `márka`, `ár`, `végsebesség`) VALUES
(1, 'asd', 12300, 20),
(2, 'hfsg', 31201, 40);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `autok`
--
ALTER TABLE `autok`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `bicikli`
--
ALTER TABLE `bicikli`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `roller`
--
ALTER TABLE `roller`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `autok`
--
ALTER TABLE `autok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `bicikli`
--
ALTER TABLE `bicikli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `roller`
--
ALTER TABLE `roller`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
