﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using bolt_beadando.Model;
using bolt_beadando.Repository;

namespace bolt_beadando.View
{
    /// <summary>
    /// Interaction logic for RollerekWindow.xaml
    /// </summary>
    public partial class RollerekWindow : Window
    {
        private RollerekRepository rollerekRepository = null;
        private List<Roller> Roller;
        private BoltContext boltContext;

        private Op operation = Op.No;
        enum Op
        {
            Add,
            Upd,
            No
        }
        public RollerekWindow()
        {
            InitializeComponent();
            rollerekRepository = new RollerekRepository(new BoltContext());
            LoadRollerekGrid();
        }

        private void LoadRollerekGrid()
        {
            Cursor = Cursors.Wait;
            Roller = rollerekRepository.GetRoller();
            rollerekGrid.ItemsSource = Roller;
            Cursor = Cursors.Arrow;

            LoadComboBoxMarka();
        }

        private void LoadComboBoxMarka()
        {
            Cursor = Cursors.Wait;
            List<Roller> lstRoller = new();
            RollerekRepository rollerekRep = new(new BoltContext());
            lstRoller = rollerekRep.GetRoller();
            comboBoxRollerek.ItemsSource = lstRoller;
            comboBoxRollerek.SelectedValue = lstRoller;
            comboBoxRollerek.DisplayMemberPath = "Marka";
            comboBoxRollerek.SelectedValuePath = "Marka";
            lstRoller = null;
            rollerekRep.Dispose();
            Cursor = Cursors.Arrow;
        }

        private void comboBoxAutok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBoxRollerek.SelectedIndex != -1)
            {
                Roller = rollerekRepository.GetRollerByMarka(comboBoxRollerek.SelectedValue.ToString());
                rollerekGrid.ItemsSource = Roller;
                comboBoxRollerAr.IsEnabled = true;
            }
        }

        private void comboBoxRoller_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBoxRollerek.SelectedIndex != -1)
            {
                Roller = rollerekRepository.GetRollerByMarka(comboBoxRollerek.SelectedValue.ToString());
                rollerekGrid.ItemsSource = Roller;
                comboBoxRollerAr.IsEnabled = true;
            }
        }

        private void textBoxRollerAr_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (comboBoxRollerAr.Text != string.Empty)
            {
                Roller = rollerekRepository.GetRollerByAr(int.Parse(comboBoxRollerAr.Text), comboBoxRollerek.SelectedValue.ToString());
                rollerekGrid.ItemsSource = Roller;
            }
        }

        private void vasarlas_Click(object sender, RoutedEventArgs e)
        {
            if (rollerekGrid.SelectedItem != null)
            {
                Roller segedRoller = rollerekGrid.SelectedItem as Roller;
                Vasarlas vasarlas = new Vasarlas(segedRoller.Id);
                vasarlas.ShowDialog();
            }
            else
            {
                MessageBox.Show("Válassz ki egy rollert a vásárlás folytatásához!");
            }
        }

        private void resetButton_Click(object sender, RoutedEventArgs e)
        {
            rollerekGrid.ItemsSource = rollerekRepository.GetRoller();
            comboBoxRollerek.SelectedIndex = -1;
            comboBoxRollerAr.IsEnabled = false;
        }

        private void hozzaadButton_Click(object sender, RoutedEventArgs e)
        {
            HozzaadWindoűw hozzaad = new HozzaadWindoűw();
            hozzaad.ShowDialog();
            this.Close();
        }
    }
}
