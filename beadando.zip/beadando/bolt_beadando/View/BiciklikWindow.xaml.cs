﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using bolt_beadando.Model;
using bolt_beadando.Repository;
using Microsoft.EntityFrameworkCore.Metadata;

namespace bolt_beadando.View
{
    /// <summary>
    /// Interaction logic for BiciklikWindow.xaml
    /// </summary>
    public partial class BiciklikWindow : Window
    {
        private BiciklikRepository biciklikRepository = null;
        private List<Bicikli> Bicikli;
        private BoltContext boltContext;

        private Op operation = Op.No;
        enum Op
        {
            Add,
            Upd,
            No
        }
        public BiciklikWindow()
        {
            InitializeComponent();
            biciklikRepository = new BiciklikRepository(new BoltContext());
            LoadBiciklikGrid();
        }

        private void LoadBiciklikGrid()
        {
            Cursor = Cursors.Wait;
            Bicikli = biciklikRepository.GetBicikli();
            biciklikGrid.ItemsSource = Bicikli;
            Cursor = Cursors.Arrow;

            LoadComboBoxMarka();
        }

        private void LoadComboBoxMarka()
        {
            Cursor = Cursors.Wait;
            List<Bicikli> lstBicikli = new();
            BiciklikRepository biciklikRep = new(new BoltContext());
            lstBicikli = biciklikRep.GetBicikli();
            comboBoxBiciklik.ItemsSource = lstBicikli;
            comboBoxBiciklik.SelectedValue = lstBicikli;
            comboBoxBiciklik.DisplayMemberPath = "Marka";
            comboBoxBiciklik.SelectedValuePath = "Marka";
            lstBicikli = null;
            biciklikRep.Dispose();
            Cursor = Cursors.Arrow;
        }

        private void comboBoxBicikli_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBoxBiciklik.SelectedIndex != -1)
            {
                Bicikli = biciklikRepository.GetBicikliByMarka(comboBoxBiciklik.SelectedValue.ToString());
                biciklikGrid.ItemsSource = Bicikli;
                comboBoxBiciklikAr.IsEnabled = true;
            }
        }

        private void textBoxBiciklik_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (comboBoxBiciklikAr.Text != string.Empty)
            {
                Bicikli = biciklikRepository.GetBicikliByAr(int.Parse(comboBoxBiciklikAr.Text), comboBoxBiciklik.SelectedValue.ToString());
                biciklikGrid.ItemsSource = Bicikli;
            }
        }

        private void resetButton_Click(object sender, RoutedEventArgs e)
        {
            biciklikGrid.ItemsSource = biciklikRepository.GetBicikli();
            comboBoxBiciklik.SelectedIndex = -1;
            comboBoxBiciklikAr.IsEnabled = false;
        }

        private void vasarlas_Click(object sender, RoutedEventArgs e)
        {
            if (biciklikGrid.SelectedItem != null)
            {
                Bicikli segedBicikli = biciklikGrid.SelectedItem as Bicikli;
                Vasarlas vasarlas = new Vasarlas(segedBicikli.Id);
                vasarlas.ShowDialog();
            }
            else
            {
                MessageBox.Show("Válassz ki egy biciklit a vásárlás folytatásához!");
            }
        }

        private void hozzaadButton_Click(object sender, RoutedEventArgs e)
        {
            HozzaadWindoűw hozzaad = new HozzaadWindoűw();
            hozzaad.ShowDialog();
            this.Close();
        }
    }
}
