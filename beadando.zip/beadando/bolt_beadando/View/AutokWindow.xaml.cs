﻿using bolt_beadando.Model;
using bolt_beadando.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using bolt_beadando.Model;
using bolt_beadando.Repository;

namespace bolt_beadando.View
{
    /// <summary>
    /// Interaction logic for AutokWindow.xaml
    /// </summary>
    public partial class AutokWindow : Window
    {
        private AutokRepository autokRepository = null;
        private List<Auto> Auto;
        private BoltContext boltContext;

        private Op operation = Op.No;
        enum Op
        {
            Add,
            Upd,
            No
        }


        public AutokWindow()
        {
            InitializeComponent();
            autokRepository = new AutokRepository (new BoltContext());
            LoadAutokGrid();
            
        }

        private void LoadAutokGrid()
        {
            Cursor = Cursors.Wait;
            Auto = autokRepository.GetAutok();
            autokGrid.ItemsSource = Auto;
            Cursor = Cursors.Arrow;
            
            LoadComboBoxMarka();
        }

        private void LoadComboBoxMarka()
        {
            Cursor = Cursors.Wait;
            List<Auto> lstAuto = new();
            AutokRepository autokRep = new(new BoltContext());
            lstAuto = autokRep.GetAutok();
            comboBoxAutok.ItemsSource = lstAuto;
            comboBoxAutok.SelectedValue = lstAuto;
            comboBoxAutok.DisplayMemberPath = "Marka";
            comboBoxAutok.SelectedValuePath = "Marka";
            lstAuto = null;
            autokRep.Dispose();
            Cursor = Cursors.Arrow;
        }

        private void comboBoxAutok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBoxAutok.SelectedIndex != -1)
            {
                Auto = autokRepository.GetAutokByMarka(comboBoxAutok.SelectedValue.ToString());
                autokGrid.ItemsSource = Auto;
                comboBoxAutokAr.IsEnabled = true;
            }
        }

        private void textBoxAutokAr_TextChanged(object sender, TextChangedEventArgs e)
        {
            
            if (comboBoxAutokAr.Text != string.Empty)
            {
                Auto = autokRepository.GetAutokByAr(int.Parse(comboBoxAutokAr.Text), comboBoxAutok.SelectedValue.ToString());
                autokGrid.ItemsSource = Auto;
            }

            
        }

        private void resetButton_Click(object sender, RoutedEventArgs e)
        {

            autokGrid.ItemsSource = autokRepository.GetAutok();
            comboBoxAutok.SelectedIndex = -1;
            comboBoxAutokAr.IsEnabled = false;
            
        }

        private void vasarlas_Click(object sender, RoutedEventArgs e)
        {
            if (autokGrid.SelectedItem != null)
            {
                Auto segedAuto = autokGrid.SelectedItem as Auto;
                Vasarlas vasarlas = new Vasarlas(segedAuto.Id);
                vasarlas.ShowDialog();
            }
            else
            {
                MessageBox.Show("Válassz ki egy autót a vásárlás folytatásához!");
            }
            
        }

        private void hozzaadButton_Click(object sender, RoutedEventArgs e)
        {
            HozzaadWindoűw hozzaad = new HozzaadWindoűw();
            hozzaad.ShowDialog();
            this.Close();
        }
    }
}
