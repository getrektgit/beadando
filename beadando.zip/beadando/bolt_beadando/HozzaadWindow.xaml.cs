﻿using bolt_beadando.Repository;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bolt_beadando
{
    /// <summary>
    /// Interaction logic for HozzaadWindoűw.xaml
    /// </summary>
    public partial class HozzaadWindoűw : Window
    {

        public HozzaadWindoűw()
        {
            InitializeComponent();
        }

        private string returnComboText()
        {
            return jarmuComboBox.Text;
        }

        private void feltoltButton_Click_1(object sender, RoutedEventArgs e)
        {

            MySqlConnection conn = new MySqlConnection(ConfigurationManager.AppSettings.Get("DBurl"));
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();
            comm.CommandTimeout = 200;

            comm.CommandText = $"INSERT INTO {jarmuComboBox.Text} (márka, ár, végsebesség) VALUES (?marka, ?ar, ?vegsebesseg)";

            comm.Parameters.AddWithValue("?marka", markaTextbox.Text);
            comm.Parameters.AddWithValue("?ar", int.Parse(arTextbox.Text));
            comm.Parameters.AddWithValue("?vegsebesseg", int.Parse(vegsebessegTextbox.Text));

            comm.ExecuteNonQuery();
            conn.Close();
            this.Close();
        }
    }
}
