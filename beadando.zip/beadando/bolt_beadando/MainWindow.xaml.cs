﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using bolt_beadando.Model;
using bolt_beadando.View;

namespace bolt_beadando
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AutokWindow autokWindow;
        private BiciklikWindow biciklikWindow;
        private RollerekWindow rollerekWindow;

        public MainWindow()
        {
            InitializeComponent();
            CheckDatabaseConnection();
        }

        private void CheckDatabaseConnection()
        {
            try
            {
                BoltContext dbcontext = new();
                if (!dbcontext.Database.CanConnect())
                {
                    MessageBox.Show("Database Connection Failed");
                    System.Environment.Exit(1);
                }
                dbcontext.Dispose();
            }
            catch (Exception e)
            {
                MessageBox.Show("Database Connection Failed" + e.Message);
                System.Environment.Exit(1);
            }
        }

        private void autoButton_Click(object sender, RoutedEventArgs e)
        {
            AutokWindow autokWindow = new();
            autokWindow.Show();
            
        }

        private void rollerButton_Click(object sender, RoutedEventArgs e)
        {
            RollerekWindow rollerekWindow = new RollerekWindow();
            rollerekWindow.Show();
        }

        private void bicikliButton_Click(object sender, RoutedEventArgs e)
        {
            BiciklikWindow biciklikWindow = new BiciklikWindow();
            biciklikWindow.Show();
        }
    }
}
