﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bolt_beadando.Model
{
    internal class BoltContext : DbContext
    {
        private string connectionString;

        public BoltContext()
        {
            this.connectionString = ConfigurationManager.AppSettings.Get("DBurl");
        }

        public DbSet<Auto> Autok { get; set; }
        public DbSet<Bicikli> Biciklik { get; set; }
        public DbSet<Roller> Rollerek { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL(connectionString);
        }
    }
}
