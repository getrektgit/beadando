﻿using bolt_beadando.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bolt_beadando.Repository
{
    internal class AutokRepository
    {
        private BoltContext boltContext;
        public AutokRepository(BoltContext boltContext)
        {
            this.boltContext = boltContext;
        }

        public List<Auto> GetAutok()
        {
            return boltContext.Autok.ToList();
        }

        public List<Auto> GetAutokByMarka(string markanev)
        {
            return boltContext.Autok.Where(p => p.Marka == markanev).ToList();
        }

        public List<Auto> GetAutokByAr(int ar, string markanev)
        {
            return boltContext.Autok.Where(p => p.Ar >= ar && p.Marka == markanev).ToList();
        }

        public Auto GetAutoById(int id)
        {
            return boltContext.Autok.Find(id);
        }

        public void InsertAutok(Auto auto)
        {
            boltContext.Autok.Add(auto);
        }

        public void DeleteAutok(int autokID)
        {
            Auto autok = boltContext.Autok.Find(autokID);
            boltContext.Autok.Remove(autok);
        }

        public void UpdateAutok(Auto auto)
        {
            boltContext.Autok.Find(auto.Id).Marka = auto.Marka;
            boltContext.Autok.Find(auto.Id).Ar = auto.Ar;
            boltContext.Autok.Find(auto.Id).Vegsebesseg = auto.Vegsebesseg;
        }

        public void Save()
        {
            boltContext.SaveChanges();
        }

        public void Dispose()
        {
            boltContext.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
