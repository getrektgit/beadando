﻿using bolt_beadando.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bolt_beadando.Repository
{
    internal class RollerekRepository
    {
        private BoltContext boltContext;
        public RollerekRepository(BoltContext boltContext)
        {
            this.boltContext = boltContext;
        }

        public List<Roller> GetRoller()
        {
            return boltContext.Rollerek.ToList();
        }

        public List<Roller> GetRollerByMarka(string markanev)
        {
            return boltContext.Rollerek.Where(p => p.Marka == markanev).ToList();
        }

        public List<Roller> GetRollerByAr(int ar, string markanev)
        {
            return boltContext.Rollerek.Where(p => p.Ar >= ar && p.Marka == markanev).ToList();
        }


        public Roller GetRollerById(int id)
        {
            return boltContext.Rollerek.Find(id);
        }

        public void InsertRoller(Roller roller)
        {
            boltContext.Rollerek.Add(roller);
        }

        public void DeleteRoller(int rollerID)
        {
            Roller roller = boltContext.Rollerek.Find(rollerID);
            boltContext.Rollerek.Remove(roller);
        }

        public void UpdateRoller(Roller roller)
        {
            boltContext.Rollerek.Find(roller.Id).Marka = roller.Marka;
            boltContext.Rollerek.Find(roller.Id).Ar = roller.Ar;
            boltContext.Autok.Find(roller.Id).Vegsebesseg = roller.vegsebesseg;
        }

        public void Save()
        {
            boltContext.SaveChanges();
        }

        public void Dispose()
        {
            boltContext.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
