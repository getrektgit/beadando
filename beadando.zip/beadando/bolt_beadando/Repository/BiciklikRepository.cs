﻿using bolt_beadando.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bolt_beadando.Repository
{
    internal class BiciklikRepository
    {
        private BoltContext boltContext;
        public BiciklikRepository(BoltContext boltContext)
        {
            this.boltContext = boltContext;
        }

        public List<Bicikli> GetBicikli()
        {
            return boltContext.Biciklik.ToList();
        }

        public List<Bicikli> GetBicikliByMarka(string markanev)
        {
            return boltContext.Biciklik.Where(p => p.Marka == markanev).ToList();
        }

        public List<Bicikli> GetBicikliByAr(int ar, string markanev)
        {
            return boltContext.Biciklik.Where(p => p.Ar >= ar && p.Marka == markanev).ToList();
        }

        public Bicikli GetBicikliById(int id)
        {
            return boltContext.Biciklik.Find(id);
        }

        public void InsertBicikli(Bicikli bicikli)
        {
            boltContext.Biciklik.Add(bicikli);
        }

        public void DeleteBicikli(int bicikliID)
        {
            Bicikli bicikli = boltContext.Biciklik.Find(bicikliID);
            boltContext.Biciklik.Remove(bicikli);
        }

        public void UpdateBicikli(Bicikli bicikli)
        {
            boltContext.Biciklik.Find(bicikli.Id).Marka = bicikli.Marka;
            boltContext.Biciklik.Find(bicikli.Id).Ar = bicikli.Ar;
            boltContext.Autok.Find(bicikli.Id).Vegsebesseg = bicikli.vegsebesseg;
        }

        public void Save()
        {
            boltContext.SaveChanges();
        }

        public void Dispose()
        {
            boltContext.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
